# Roblox Mobil Kasa — Android uygulama projesi

**Sürüm:** 1.0.0 — Android 11+ (API 30), Java, native Android WebView, çevrimdışı şifreli kasa.  
**Önemli:** Bu ZIP **APK değildir**. APK üretmek için Android Studio veya GitHub Actions gerekir.

## Özellikler

- Uygulama günlük kullanımda ayrı kasa ana şifresi istemez: Android cihaz PIN/desen/parmak izi veya güçlü yüz tanıma kullanır.
- AES-256-GCM ile şifreli kasa; anahtar Android Keystore'a bağlıdır, sunucuya yüklenmez.
- Gerçek doğum tarihini bir kez seçme ve kaydetme.
- Her kayıt için rastgele kullanıcı adı ve 22 karakterlik benzersiz güçlü şifre üretme.
- **Kayıt sayfasını açmadan önce** her taslağı **Bekleyenler** bölümüne şifreli kaydetme.
- `https://www.roblox.com/tr/CreateAccount` sayfasını uygulama içindeki WebView ile açma.
- Uygun DOM alanları mevcutsa kullanıcı adı, şifre ve doğum tarihini doldurma. Roblox sayfa yapısını değiştirirse eksik alanlar elle girilir.
- CAPTCHA çözme ve kayıt gönderme kullanıcıya aittir. Bunu otomatikleştirmez.
- Roblox sayfasında kayıt sonrası beklenen kullanıcı adını doğrulayabilirse otomatik “Başarılı” statüsüne taşıma; doğrulanamazsa kullanıcı manuel onaylar.
- Kayıt arama, şifre görüntüleme/kopyalama, kayıt silme, manuel eski hesap ekleme.
- Başarılı hesaplar için TXT (`kullanıcıadı:şifre`) ve CSV indirme.
- Eski PC eklentisinden gelen TXT kullanıcıadı:şifre listesini içe aktarma (cookie/token içe aktarılmaz).
- Mevcut (zaten oluşturulmuş) hesapları kullanıcı adı ve şifresiyle kasaya elle ekleme.
- Taşınabilir parola korumalı JSON yedekleme / geri yükleme (yalnızca yedek alırken ekstra parola gerekir).
- Varsayılan e-posta *etiketi*: Chrome/Google varsayılan hesabını değiştirmez.

## Windows 11 bilgisayarda APK oluşturma

**Kolay seçenek:** Android Studio kurup SDK Manager içinden Android API 35 bileşenini yükledikten sonra proje içindeki `APK-OLUSTUR-WINDOWS.bat` dosyasını çift tıkla. Java 17 ve internet bağlantısı gereklidir. APK çıktısı `app\build\outputs\apk\debug\app-debug.apk` konumunda oluşur.

**Android Studio menüsüyle:**

1. Android Studio'yu resmi https://developer.android.com/studio adresinden kur.
2. **Open** > bu projenin `RobloxMobilKasa` klasörünü seç.
3. Android Studio internet bağlantısıyla Android SDK Platform 35, Gradle 8.9 ve Android Gradle Plugin 8.7.3'ü indirip senkronize etmelidir.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** menüsünü aç.
5. Çıktı dosyası: `app/build/outputs/apk/debug/app-debug.apk`.
6. Bu `app-debug.apk` dosyasını telefonuna aktar ve telefonda Dosyalar uygulamasından aç.
7. Android “Bu kaynaktan yüklemeye izin ver” istiyorsa, sadece güvendiğin kendi derlediğin APK için izin ver.
8. İlk açışta Android'in güvenli ekran kilidini doğrula. Gerçek doğum tarihini seçip yeni kullanıcı adı/şifre oluştur.

### Android Studio olmadan: GitHub Actions

1. Kendi **özel (private)** GitHub depona bu proje içeriğini yükle.
2. GitHub > **Actions > Android APK olustur > Run workflow** seç.
3. İşlem tamamlanırsa `RobloxMobilKasa-APK` adlı **Actions artifact** dosyasını indir.
4. İndirilen ZIP'in içindeki `app-debug.apk` dosyasını Android telefonuna kur.
5. Projede `.github/workflows/android-apk.yml` hazırdır. İş akışının çalışması için kendi deponda Actions'ın izinli olması gerekir.

## Güvenlik ve veri kaybı uyarıları

- Cihaz PIN'i/parmak izi kasayı açar; ayrı kasa parolası olmaz.
- **Telefonu sıfırlarsan, ekran kilidini kaldırırsan, uygulamayı silersen veya başka telefona geçersen Android Keystore anahtarı geri getirilemeyebilir.** Böyle bir işlemden *önce* “Şifreli JSON yedeği” al ve yedekleme parolasını güvenli sakla.
- Düz TXT/CSV'ler şifrelenmez. Paylaşma; indirince güvenli yerde tut.
- WebView, Roblox tarafından kısıtlanabilir. Bu durumda kayıt sayfasını Chrome'da açıp bilgileri kopyalayarak ilerle; kasada bekleyenler korunur.
- Uygulama cookie, session token ve `.ROBLOSECURITY` verisini **okumaz, kaydetmez veya dışa aktarmaz**.
- Uygulama CAPTCHA atlatmaz; kayıtları otomatik göndermez veya tekrar tekrar hesap açmaz.
- Android telefon uygulamasının verileri ve önceki Chrome eklenti kasası **farklıdır**. Önceki kasayı doğrudan açamaz; bilgisayardaki kasadan TXT dışa aktarıp uygulamanın TXT içe aktarma özelliğini kullanabilirsin.

## Proje dosyaları

- `app/src/main/java/com/pixelya/robloxvault/MainActivity.java`: Telefon arayüzü, kayıt ekranı, kullanıcı onayı, dışa/içe aktarma
- `VaultStore.java`: Android Keystore cihaz korumalı AES-GCM yerel kasa ve kayıt durumları
- `AccountGenerator.java`: Güçlü parola + benzersiz yerel kullanıcı adı üretimi
- `FormScript.java`: Roblox sayfasındaki form alanlarını doldurmaya yönelik JS, **submit yok**
- `BackupCodec.java`: PBKDF2-SHA256 + AES-256-GCM ile taşınabilir şifreli yedek
- `app/src/main/AndroidManifest.xml`: Ağ ve biometrik yetkileri
- `.github/workflows/android-apk.yml`: GitHub Actions APK derleme akışı

## Teknik sınırlamalar ve testler

Kaynak kodu hazırlayan ortamda Android SDK/Gradle ve internete erişim bulunmadığından **APK derlemesi ve Android cihaz testi burada yapılamadı**. Standart Java ile 500 kullanıcı adı ve parola üretme testleri çalıştırıldı. Gerçek Roblox formundaki dinamik öğelerin seçicileri cihazda denenmelidir. Hata çıkarsa derleme çıktısını paylaş.
