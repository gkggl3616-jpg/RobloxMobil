import java.util.HashSet;
import java.util.Set;
import com.pixelya.robloxvault.AccountGenerator;
public class TestGenerator {
  public static void main(String[] args) {
    Set<String> used = new HashSet<>();
    for(int i=0;i<500;i++) {
      String user=AccountGenerator.username("Nova",used);
      String pass=AccountGenerator.password();
      if(!user.matches("[A-Za-z0-9]{3,20}")) throw new RuntimeException("Bad username");
      if(!used.add(user)) throw new RuntimeException("Duplicate username");
      if(pass.length()!=22||!pass.matches(".*[A-Z].*")||!pass.matches(".*[a-z].*")||!pass.matches(".*[0-9].*")||!pass.matches(".*[!@#$%*\\-_].*")) throw new RuntimeException("Weak password");
    }
    System.out.println("OK: 500 unique usernames + strong passwords");
  }
}
