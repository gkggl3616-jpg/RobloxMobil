package com.pixelya.robloxvault;

import org.json.JSONObject;

/** User-triggered field filling only. Never submits, reads cookies, or touches CAPTCHA. */
public final class FormScript {
    private FormScript() {}

    public static String fill(String username, String password, String isoBirth) {
        String[] p = isoBirth.split("-");
        int year = Integer.parseInt(p[0]), month = Integer.parseInt(p[1]), day = Integer.parseInt(p[2]);
        return "(function(){\n" +
            "const U=" + JSONObject.quote(username) + ", P=" + JSONObject.quote(password) + ";\n" +
            "let count={username:false,password:false,day:false,month:false,year:false};\n" +
            "function first(ss){ for(const s of ss){try{let e=document.querySelector(s); if(e)return e;}catch(x){}} return null;}\n" +
            "function put(el,v){if(!el)return false;let d=Object.getOwnPropertyDescriptor(el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value'); if(d&&d.set)d.set.call(el,String(v));else el.value=String(v);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));el.dispatchEvent(new Event('blur',{bubbles:true}));return true;}\n" +
            "function sel(ss,number,aliases){let el=first(ss);if(!el)return false;if(el.tagName==='SELECT'){let opt=Array.from(el.options).find(o=>Number(o.value)===number||Number(o.textContent.trim())===number||aliases.some(a=>o.textContent.trim().toLowerCase()===a)); if(!opt)return false;el.value=opt.value;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;} if(el.tagName==='INPUT')return put(el,number);return false;}\n" +
            "count.username=put(first(['#signup-username','#Username','input[name=username]','input[autocomplete=username]','input[placeholder*=Username]','input[placeholder*=username]']),U);\n" +
            "count.password=put(first(['#signup-password','#Password','input[name=password]','input[autocomplete=new-password]','input[type=password]']),P);\n" +
            "count.day=sel(['#DayDropdown','select[name=day]','select[name*=day]','input[name=day]'],"+day+",[]);\n" +
            "count.month=sel(['#MonthDropdown','select[name=month]','select[name*=month]','input[name=month]'],"+month+",['" + MONTHS_EN[month-1] + "','" + MONTHS_TR[month-1] + "']);\n" +
            "count.year=sel(['#YearDropdown','select[name=year]','select[name*=year]','input[name=year]'],"+year+",[]);\n" +
            "return JSON.stringify(count);\n" +
            "})()";
    }

    private static final String[] MONTHS_EN = {"january","february","march","april","may","june","july","august","september","october","november","december"};
    private static final String[] MONTHS_TR = {"ocak","şubat","mart","nisan","mayıs","haziran","temmuz","ağustos","eylül","ekim","kasım","aralık"};

    public static String verifyUsername(String expected) {
        return "(function(){const want=" + JSONObject.quote(expected.toLowerCase(java.util.Locale.ROOT)) + ";" +
            "const selectors=['#nav-username','[data-testid=nav-username]','.navbar-right .username','.nav-username','.user-name'];" +
            "for(const s of selectors){let e=document.querySelector(s);if(e&&e.textContent.trim().toLowerCase()===want)return true;}" +
            "return false;})()";
    }
}
