package com.pixelya.robloxvault;

import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Portable backup requires a backup password; everyday vault does NOT. */
public final class BackupCodec {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int ITERATIONS = 240000;
    private static final String FORMAT = "roblox-mobil-vault-backup-v1";
    private static final byte[] AAD = FORMAT.getBytes(StandardCharsets.UTF_8);
    private BackupCodec() {}

    private static SecretKeySpec derive(char[] pass, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pass, salt, ITERATIONS, 256);
        try {
            byte[] bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return new SecretKeySpec(bytes, "AES");
        } finally { spec.clearPassword(); }
    }

    public static String encrypt(String plain, char[] password) throws Exception {
        byte[] salt = new byte[16], iv = new byte[12];
        RANDOM.nextBytes(salt);
        RANDOM.nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, derive(password, salt), new GCMParameterSpec(128, iv));
        cipher.updateAAD(AAD);
        byte[] out = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        JSONObject o = new JSONObject();
        o.put("format", FORMAT);
        o.put("iterations", ITERATIONS);
        o.put("salt", Base64.encodeToString(salt, Base64.NO_WRAP));
        o.put("iv", Base64.encodeToString(iv, Base64.NO_WRAP));
        o.put("data", Base64.encodeToString(out, Base64.NO_WRAP));
        return o.toString(2);
    }

    public static String decrypt(String encoded, char[] password) throws Exception {
        JSONObject o = new JSONObject(encoded);
        if (!FORMAT.equals(o.getString("format")) || o.getInt("iterations") != ITERATIONS)
            throw new IllegalArgumentException("Desteklenmeyen yedek biçimi");
        byte[] salt = Base64.decode(o.getString("salt"), Base64.NO_WRAP);
        byte[] iv = Base64.decode(o.getString("iv"), Base64.NO_WRAP);
        byte[] data = Base64.decode(o.getString("data"), Base64.NO_WRAP);
        if (salt.length != 16 || iv.length != 12 || data.length > 10_000_000)
            throw new IllegalArgumentException("Geçersiz yedek");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, derive(password, salt), new GCMParameterSpec(128, iv));
        cipher.updateAAD(AAD);
        return new String(cipher.doFinal(data), StandardCharsets.UTF_8);
    }
}
