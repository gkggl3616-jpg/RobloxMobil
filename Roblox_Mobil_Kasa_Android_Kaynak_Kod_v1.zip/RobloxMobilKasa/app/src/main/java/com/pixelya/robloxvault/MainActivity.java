package com.pixelya.robloxvault;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.biometrics.BiometricManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.Editable;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** Local-first Roblox sign-up helper; never clicks Submit/CAPTCHA or reads session cookies. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0B1022, SURFACE = 0xFF17213B;
    private static final int HIGHLIGHT = 0xFF6387FF, TEXT = 0xFFF2F5FF, MUTED = 0xFFABBCE0;
    private static final int CREATE_FILE = 101, OPEN_BACKUP = 102, OPEN_TXT = 103;
    private static final String REGISTRATION_URL = "https://www.roblox.com/tr/CreateAccount";

    private VaultStore vault;
    private LinearLayout main;
    private String selectedBirth = "";
    private EditText prefixInput, emailInput;
    private String screen = "locked";
    private JSONObject activeRecord;
    private WebView web;
    private boolean initialFillAttempted;
    private String pendingFile;
    private boolean choosingFile;
    private long backgroundAt;
    private boolean authenticating;
    private Runnable retryOnUnlock;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showLocked();
        unlock(null);
    }

    @Override protected void onStop() {
        super.onStop();
        if (!choosingFile) backgroundAt = SystemClock.elapsedRealtime();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!authenticating && !choosingFile && vault != null && backgroundAt > 0 &&
                SystemClock.elapsedRealtime() - backgroundAt > 25000) {
            vault = null;
            activeRecord = null;
            if (web != null) { web.destroy(); web = null; }
            showLocked();
            unlock(null);
        }
        backgroundAt = 0;
    }

    private void showLocked() {
        screen = "locked";
        base("Roblox Mobil Kasa", "Bu telefonun ekran kilidiyle korunan yerel hesap kasası.");
        section("Cihaz doğrulaması");
        note("Ayrı bir kasa şifresi yok. Parmak izi, yüz tanıma (destekleniyorsa) ya da telefon PIN/deseniyle açılır.");
        button(main, "Telefonla kilidi aç", true, () -> unlock(null));
        note("Kasanın anahtarı Android Keystore'da tutulur, sunucuya gönderilmez. Telefon kilidi kaldırılır veya uygulama silinirse kasaya erişim kaybolabilir.");
    }

    private void unlock(Runnable after) {
        if (authenticating) return;
        if (after != null) retryOnUnlock = after;
        KeyguardManager kg = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (kg == null || !kg.isDeviceSecure()) {
            error("Önce telefonunun Ayarlar > Güvenlik bölümünden PIN, desen veya parmak izi ayarla.");
            return;
        }
        try { VaultStore.createKeyIfMissing(); }
        catch (Exception e) { error("Güvenli anahtar oluşturulamadı: " + e.getMessage()); return; }
        authenticating = true;
        BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                .setTitle("Roblox Mobil Kasa")
                .setSubtitle("Kasayı telefonunla doğrula")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build();
        prompt.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authenticating = false;
                try {
                    vault = new VaultStore(MainActivity.this);
                    vault.load();
                    selectedBirth = vault.birth();
                    showDashboard();
                    if (retryOnUnlock != null) {
                        Runnable retry = retryOnUnlock;
                        retryOnUnlock = null;
                        retry.run();
                    }
                } catch (Exception e) {
                    vault = null;
                    showLocked();
                    error("Kasa açılamadı: " + e.getMessage());
                }
            }
            @Override public void onAuthenticationError(int code, CharSequence message) {
                authenticating = false;
                retryOnUnlock = null;
                Toast.makeText(MainActivity.this, "Doğrulama: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private interface SecureTask { void run() throws Exception; }
    private void secure(SecureTask task) {
        if (vault == null) { unlock(() -> secure(task)); return; }
        try { task.run(); }
        catch (android.security.keystore.UserNotAuthenticatedException e) {
            unlock(() -> secure(task));
        } catch (Exception e) {
            error("İşlem yapılamadı: " + e.getMessage());
        }
    }

    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }
    private void pad(View v, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(bottom));
        main.addView(v, p);
    }
    private void base(String title, String subtitle) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL); container.setBackgroundColor(BG);
        setContentView(container);
        LinearLayout head = new LinearLayout(this);
        head.setPadding(dp(19), dp(22), dp(19), dp(16));
        head.setOrientation(LinearLayout.VERTICAL);
        head.addView(label("◆ " + title, 24, TEXT, true));
        head.addView(label(subtitle, 12, MUTED, false));
        container.addView(head);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        container.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(18), dp(5), dp(18), dp(26));
        scroll.addView(main);
    }
    private void section(String value) { pad(label(value, 18, TEXT, true), 6); }
    private void note(String value) { pad(label(value, 13, MUTED, false), 12); }
    private Button button(LinearLayout parent, String text, boolean primary, Runnable action) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(TEXT);
        b.setBackground(background(primary ? 0xFF405FD5 : 0xFF223150, 13));
        b.setPadding(dp(12), dp(11), dp(12), dp(11));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(9));
        parent.addView(b,p);
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setTextColor(TEXT); e.setHintTextColor(MUTED);
        e.setHint(hint); e.setSingleLine(true);
        e.setTextSize(15); e.setText(value);
        e.setPadding(dp(13), dp(13), dp(13), dp(13));
        e.setBackground(background(SURFACE, 11));
        pad(e,12);
        return e;
    }
    private void error(String message) {
        new AlertDialog.Builder(this).setTitle("Bilgi").setMessage(message)
                .setPositiveButton("Tamam", null).show();
    }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }

    private void showDashboard() {
        if (vault == null) { showLocked(); return; }
        screen = "dashboard";
        base("Roblox Mobil Kasa", "Android • Telefon doğrulaması • Şifreli yerel depolama");
        int[] c = vault.counts();
        TextView stats = label("✓ " + c[0] + " başarılı     ◷ " + c[1] + " bekleyen", 18, 0xFFBED0FF, true);
        stats.setPadding(dp(14),dp(16),dp(14),dp(16));
        stats.setBackground(background(SURFACE, 14)); pad(stats, 20);
        section("Kayıt ayarları");
        note("Doğum tarihini gerçek bilgilerine göre bir kez seç. Otomatik yanlış yaş üretmiyoruz.");
        String dob = selectedBirth;
        button(main, dob.isEmpty()? "Doğum tarihini seç" : "Doğum tarihi: " + dob + "  ✎", false, this::chooseBirth);
        prefixInput = field("Kullanıcı adı öneki (Nova)", vault.prefix());
        emailInput = field("Varsayılan e-posta etiketi (isteğe bağlı)", vault.email());
        note("E-posta etiketi yalnızca kasada gruplama içindir. Telefonun Google hesabını değiştirmez.");
        button(main, "Yeni bilgiler üret + bekleyenlere kaydet", true, this::generate);
        button(main, "Şifreli hesap kasasını aç", false, this::showVault);
        button(main, "Mevcut hesabı elle kasaya ekle", false, this::addExistingDialog);
        button(main, "Bilgisayardan TXT hesap listesi aktar", false, this::importTxt);
        section("Yedekleme ve dışa aktarma");
        button(main, "Başarılı hesaplar → TXT indir", false, () -> confirmPlainExport(false));
        button(main, "Başarılı hesaplar → CSV indir", false, () -> confirmPlainExport(true));
        button(main, "Şifreli JSON yedeği oluştur", false, this::exportBackup);
        button(main, "Şifreli JSON yedeğinden geri yükle", false, this::importBackup);
        note("TXT/CSV şifrelenmez. Şifreli JSON yedeği taşınabilir ve yalnızca yedekleme için oluşturduğun ayrı bir parolayla açılır.");
        button(main, "Kasayı kilitle", false, () -> { vault = null; showLocked(); });
    }

    private void chooseBirth() {
        int y=2000,m=0,d=1;
        try { if (!selectedBirth.isEmpty()) { String[] p=selectedBirth.split("-"); y=Integer.parseInt(p[0]);m=Integer.parseInt(p[1])-1;d=Integer.parseInt(p[2]); } }
        catch (Exception ignored) {}
        DatePickerDialog dialog = new DatePickerDialog(this, (DatePicker view,int year,int month,int day) -> {
            selectedBirth=String.format(Locale.US,"%04d-%02d-%02d",year,month+1,day);
            secure(() -> vault.config(selectedBirth, emailInput.getText().toString().trim(),prefixInput.getText().toString().trim()));
            showDashboard();
        },y,m,d);
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    private void generate() {
        if (TextUtils.isEmpty(selectedBirth)) { error("Önce gerçek doğum tarihini seç."); return; }
        final String prefix = prefixInput.getText().toString().trim();
        final String email = emailInput.getText().toString().trim();
        secure(() -> {
            vault.config(selectedBirth,email,prefix);
            String user = AccountGenerator.username(prefix,vault.usedNames());
            String pass = AccountGenerator.password();
            activeRecord = vault.addPending(user,pass,selectedBirth,email);
            new AlertDialog.Builder(this)
                    .setTitle("Bilgiler kasaya kaydedildi")
                    .setMessage("Kullanıcı adı: " + user + "\n\nŞifre üretildi (22 karakter).\n\nDurum: BEKLEYEN. Roblox kaydı başarıyla tamamlanınca onayla.")
                    .setPositiveButton("Roblox kayıt sayfasını aç", (x,y)->showRegistration())
                    .setNegativeButton("Kasaya dön", (x,y)->showDashboard())
                    .show();
        });
    }

    private void showRegistration() {
        if (vault == null || activeRecord == null) { showDashboard(); return; }
        screen = "register"; initialFillAttempted = false;
        final String user = activeRecord.optString("username");
        final String pass = activeRecord.optString("password");
        final String birth = activeRecord.optString("birth");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        TextView heading = label("Roblox kayıt • " + user, 17, TEXT, true);
        heading.setPadding(dp(15),dp(8),dp(15),dp(8)); root.addView(heading);
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(dp(9),0,dp(9),dp(6)); root.addView(actions);
        addMiniButton(actions,"Doldur",()->fillWebForm(user,pass,birth));
        addMiniButton(actions,"Kullanıcı kopyala",()->copySecret("Kullanıcı adı",user));
        addMiniButton(actions,"Şifre kopyala",()->copySecret("Şifre",pass));
        addMiniButton(actions,"Chrome",()->{
            Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse(REGISTRATION_URL));
            startActivity(i);
            toast("Chrome'da otomatik doldurma yoktur; bilgileri uygulamadan kopyalayabilirsin.");
        });
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if ("https".equalsIgnoreCase(uri.getScheme()) && host != null &&
                    (host.equalsIgnoreCase("roblox.com") || host.toLowerCase(Locale.ROOT).endsWith(".roblox.com"))) {
                    return false;
                }
                if ("https".equalsIgnoreCase(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW,uri));
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.toLowerCase(Locale.ROOT).contains("createaccount") && !initialFillAttempted) {
                    initialFillAttempted = true;
                    view.postDelayed(() -> { if (web==view) fillWebForm(user,pass,birth); }, 1400);
                }
                if ((url.toLowerCase(Locale.ROOT).matches("https://(www\\.)?roblox\\.com/(home|users/.*)") ||
                        url.toLowerCase(Locale.ROOT).contains("roblox.com/home?")) && web == view) {
                    view.postDelayed(() -> checkForVerifiedUsername(view, user), 1200);
                }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        TextView foot = label("CAPTCHA ve kayıt onayı sana ait. Roblox WebView'i reddederse Chrome seçeneğini kullan.", 11,MUTED,false);
        foot.setPadding(dp(12),dp(4),dp(12),dp(4));root.addView(foot);
        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(dp(9),dp(4),dp(9),dp(12));root.addView(bottom);
        addMiniButton(bottom,"✓ Kayıt tamamlandı",this::askConfirmActive);
        addMiniButton(bottom,"← Kasaya dön", () -> { destroyWeb(); showDashboard(); });
        web.loadUrl(REGISTRATION_URL);
    }

    private void addMiniButton(LinearLayout parent, String caption, Runnable action) {
        Button b = new Button(this);
        b.setText(caption); b.setTextSize(11); b.setAllCaps(false);
        b.setTextColor(TEXT); b.setBackground(background(0xFF263A65,10));
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,dp(45),1);
        params.setMargins(dp(2),0,dp(2),0);
        parent.addView(b,params);
        b.setOnClickListener(v -> action.run());
    }

    private void fillWebForm(String user, String pass, String birth) {
        if (web == null) return;
        try {
            web.evaluateJavascript(FormScript.fill(user,pass,birth), result -> {
                try {
                    String decoded = new JSONArray("["+result+"]").getString(0);
                    JSONObject state = new JSONObject(decoded);
                    boolean userOK=state.optBoolean("username"), passOK=state.optBoolean("password");
                    boolean dateOK=state.optBoolean("day") && state.optBoolean("month") && state.optBoolean("year");
                    if (!userOK || !passOK || !dateOK) {
                        toast("Doldurma: kullanıcı " + (userOK?"✓":"✕") +
                              ", şifre " + (passOK?"✓":"✕") + ", tarih " + (dateOK?"✓":"manuel") +
                              ". Eksik alanları elle tamamla.");
                    } else toast("Alanlar dolduruldu. CAPTCHA ve kayıt onayı sende.");
                } catch(Exception e) { toast("Otomatik doldurma doğrulanamadı. Alanları kontrol et."); }
            });
        } catch(Exception e) { toast("Form doldurma başarısız; manuel devam edebilirsin."); }
    }

    private void checkForVerifiedUsername(WebView view, String expected) {
        if (activeRecord==null || web!=view || vault==null) return;
        if ("confirmed".equals(activeRecord.optString("status"))) return;
        view.evaluateJavascript(FormScript.verifyUsername(expected), result -> {
            if ("true".equals(result) && activeRecord != null &&
                    expected.equals(activeRecord.optString("username"))) {
                secure(() -> {
                    vault.setConfirmed(activeRecord.getString("id"));
                    activeRecord.put("status","confirmed");
                    toast("Roblox kullanıcı adı doğrulandı; hesap otomatik kasaya kaydedildi.");
                });
            }
        });
    }

    private void askConfirmActive() {
        if (activeRecord == null) return;
        String id = activeRecord.optString("id");
        new AlertDialog.Builder(this)
                .setTitle("Hesap oluşturuldu mu?")
                .setMessage("Roblox'ta kayıt başarılı olduysa " + activeRecord.optString("username") + " hesabını 'Başarılı' olarak kasaya taşı.")
                .setPositiveButton("Evet, başarılı", (d,w) -> secure(() -> {
                    vault.setConfirmed(id);
                    destroyWeb(); activeRecord=null; showVault();
                }))
                .setNegativeButton("Henüz değil",null)
                .show();
    }

    private void destroyWeb() {
        if(web!=null) { web.stopLoading(); web.destroy(); web=null; }
    }

    private void showVault() {
        if (vault==null) { showLocked(); return; }
        screen="vault";
        base("Şifreli Hesap Kasası", "Bekleyen ve başarılı hesaplar • yalnızca bu telefonda");
        int[] counts=vault.counts();
        note(counts[0] + " başarılı • " + counts[1] + " bekleyen. Bekleyenler kayıt sayfası açılmadan önce şifrelenir.");
        button(main,"← Ana sayfa",false,this::showDashboard);
        EditText search=field("Kullanıcı adı / e-posta ara", "");
        LinearLayout results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        main.addView(results);
        renderRows(results,"");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){renderRows(results,s.toString());}
            public void afterTextChanged(Editable e){}
        });
    }

    private void renderRows(LinearLayout result, String search) {
        result.removeAllViews();
        JSONArray arr=vault.accounts();
        int shown=0;
        for (int i=arr.length()-1;i>=0;i--) {
            JSONObject a=arr.optJSONObject(i);
            if (a==null)continue;
            String name=a.optString("username"), email=a.optString("email"), status=a.optString("status");
            if (!(name+" "+email).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT)))continue;
            shown++;
            LinearLayout card=new LinearLayout(this);
            card.setPadding(dp(12),dp(12),dp(12),dp(12));
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(background(SURFACE,14));
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);
            params.setMargins(0,0,0,dp(9)); result.addView(card,params);
            card.addView(label(name,17,TEXT,true));
            card.addView(label(("confirmed".equals(status)?"✓ BAŞARILI":"◷ BEKLEYEN")+
                    (email.isEmpty()?"":"  •  "+email),12,MUTED,false));
            button(card,"Görüntüle / İşlemler",false,()->accountActions(a));
        }
        if(shown==0)result.addView(label("Eşleşen kayıt bulunamadı.",14,MUTED,false));
    }

    private void accountActions(JSONObject r) {
        String id=r.optString("id"),name=r.optString("username"),pass=r.optString("password");
        String[] opts={"Kullanıcı adını kopyala","Şifreyi kopyala","Şifreyi göster",
                "Roblox formunu aç","Başarılı olarak işaretle","Kaydı sil"};
        new AlertDialog.Builder(this).setTitle(name).setItems(opts,(dlg,n)->{
            switch(n){
                case 0: copySecret("Kullanıcı adı",name);break;
                case 1: copySecret("Şifre",pass);break;
                case 2: new AlertDialog.Builder(this).setTitle("Şifre: "+name)
                        .setMessage(pass).setPositiveButton("Kapat",null).show();break;
                case 3: activeRecord=r; showRegistration();break;
                case 4: new AlertDialog.Builder(this).setTitle("Başarılı mı?")
                        .setMessage("Kaydı yalnızca Roblox hesabı gerçekten açıldıysa doğrula.")
                        .setPositiveButton("Evet",(d,w)->secure(()->{vault.setConfirmed(id);showVault();}))
                        .setNegativeButton("Vazgeç",null).show();break;
                case 5: new AlertDialog.Builder(this).setTitle("Kaydı sil?")
                        .setMessage("Silme işlemi geri alınamaz.")
                        .setPositiveButton("Sil",(d,w)->secure(()->{vault.delete(id);showVault();}))
                        .setNegativeButton("Vazgeç",null).show();break;
            }
        }).show();
    }

    private void copySecret(String title,String value) {
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText(title,value));
        toast(title+" kopyalandı. Panodaki bilgiyi başkalarıyla paylaşma.");
    }

    private String csvField(String s) {return "\""+s.replace("\"","\"\"").replace("\r","").replace("\n","")+"\"";}
    private String plainExport(boolean csv) {
        StringBuilder sb=new StringBuilder();
        if(csv)sb.append("username,password,email,created\n");
        JSONArray arr=vault.accounts();
        for(int i=0;i<arr.length();i++){
            JSONObject a=arr.optJSONObject(i);
            if(a==null||!"confirmed".equals(a.optString("status")))continue;
            String user=a.optString("username"),pass=a.optString("password");
            if(csv)sb.append(csvField(user)).append(',').append(csvField(pass)).append(',')
                    .append(csvField(a.optString("email"))).append(',').append(a.optLong("created")).append('\n');
            else sb.append(user.replace("\r","").replace("\n","")).append(':')
                    .append(pass.replace("\r","").replace("\n","")).append('\n');
        }
        return sb.toString();
    }
    private void confirmPlainExport(boolean csv) {
        new AlertDialog.Builder(this).setTitle("Şifreler düz metin olarak indirilecek")
                .setMessage("TXT/CSV dosyalarını açabilen herkes hesap şifrelerini görebilir. Güvenli yerde sakla.")
                .setPositiveButton("İndir",(d,w)->writeFile(csv?"roblox-hesaplar.csv":"roblox-hesaplar.txt",
                        csv?"text/csv":"text/plain",plainExport(csv)))
                .setNegativeButton("İptal",null).show();
    }

    private void exportBackup() {
        EditText input=new EditText(this);
        input.setHint("Yedekleme parolası (en az 12 karakter)");
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Taşınabilir şifreli yedek")
                .setMessage("Bu parola yalnızca yedeği başka telefona aktarırken gereklidir. Günlük kasa girişinde kullanılmaz.")
                .setView(input)
                .setPositiveButton("Şifrele ve indir",(dialog,which)->{
                    String p=input.getText().toString();
                    if(p.length()<12){error("En az 12 karakterlik yedekleme parolası seç.");return;}
                    secure(()->writeFile("roblox-kasa-sifreli-yedek.json","application/json",
                            BackupCodec.encrypt(vault.json(),p.toCharArray())));
                }).setNegativeButton("Vazgeç",null).show();
    }

    private void addExistingDialog() {
        LinearLayout fields = new LinearLayout(this);
        fields.setPadding(dp(20),dp(10),dp(20),dp(10));
        fields.setOrientation(LinearLayout.VERTICAL);
        EditText user = new EditText(this);
        user.setSingleLine(true); user.setHint("Kullanıcı adı");
        fields.addView(user);
        EditText pass = new EditText(this);
        pass.setSingleLine(true); pass.setHint("Şifre");
        pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        fields.addView(pass);
        new AlertDialog.Builder(this).setTitle("Mevcut hesabını ekle")
                .setMessage("Yalnızca sana ait, oluşturulmuş hesapları ekle.")
                .setView(fields)
                .setPositiveButton("Kasaya kaydet",(d,w)->secure(()->{
                    vault.addExisting(user.getText().toString().trim(),pass.getText().toString(),"");
                    toast("Hesap kaydedildi"); showVault();
                })).setNegativeButton("Vazgeç",null).show();
    }

    private void importTxt() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);
        choosingFile=true; startActivityForResult(i,OPEN_TXT);
    }

    private void importBackup() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE);
        choosingFile=true;startActivityForResult(i,OPEN_BACKUP);
    }

    private void writeFile(String filename,String mime,String content) {
        pendingFile=content;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType(mime); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_TITLE,filename);
        choosingFile=true;startActivityForResult(i,CREATE_FILE);
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        choosingFile=false;
        if(result!=RESULT_OK||data==null||data.getData()==null){pendingFile=null;return;}
        Uri uri=data.getData();
        if(request==CREATE_FILE){
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new IllegalStateException("Dosya açılamadı");
                out.write(pendingFile.getBytes(StandardCharsets.UTF_8));
                toast("Dosya kaydedildi");
            }catch(Exception e){error("Dosya yazılamadı: "+e.getMessage());}
            finally{pendingFile=null;}
        }else if(request==OPEN_BACKUP || request==OPEN_TXT){
            try(InputStream in=getContentResolver().openInputStream(uri)){
                if(in==null)throw new IllegalStateException("Dosya açılamadı");
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>10_000_000)throw new IllegalStateException("Yedek fazla büyük");}
                String backup=bytes.toString("UTF-8");
                if(request==OPEN_TXT){
                    new AlertDialog.Builder(this).setTitle("TXT içe aktarma")
                        .setMessage("Dosyadaki kullanıcıadı:şifre kayıtları 'Başarılı' olarak şifreli kasaya eklenir. Devam edilsin mi?")
                        .setPositiveButton("İçe aktar",(d,w)->secure(()->{
                            int nImported=vault.importTxt(backup);
                            toast(nImported+" hesap içe aktarıldı");showVault();
                        })).setNegativeButton("Vazgeç",null).show();
                    return;
                }
                EditText input=new EditText(this);
                input.setHint("Yedekleme parolası");
                input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
                new AlertDialog.Builder(this).setTitle("Şifreli yedeği içe aktar")
                    .setView(input)
                    .setPositiveButton("Geri yükle",(d,w)->secure(()->{
                        String plain=BackupCodec.decrypt(backup,input.getText().toString().toCharArray());
                        int count=vault.mergeJson(plain);
                        toast(count+" yeni hesap içe aktarıldı");showDashboard();
                    })).setNegativeButton("Vazgeç",null).show();
            }catch(Exception e){error("Yedek okunamadı: "+e.getMessage());}
        }
    }

    @Override public void onBackPressed() {
        if("register".equals(screen)){
            destroyWeb();showDashboard();
        }else if("vault".equals(screen))showDashboard();
        else super.onBackPressed();
    }
}
