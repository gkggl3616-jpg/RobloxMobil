package com.pixelya.robloxvault;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Private, device-bound and authenticated encrypted storage: NO cookies or tokens. */
public final class VaultStore {
    private static final String ALIAS = "roblox_mobil_kasa_aes_v1";
    private static final String PREFS = "local_device_vault";
    private static final String DATA = "ciphertext";
    private final SharedPreferences prefs;
    private JSONObject root;

    public VaultStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void createKeyIfMissing() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return;
        KeyGenerator keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        keyGen.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setUserAuthenticationParameters(300,
                        KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL)
                .build());
        keyGen.generateKey();
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    public void load() throws Exception {
        String value = prefs.getString(DATA, null);
        if (value == null) {
            root = new JSONObject();
            root.put("birth", "");
            root.put("email", "");
            root.put("prefix", "Nova");
            root.put("accounts", new JSONArray());
            save();
            return;
        }
        JSONObject stored = new JSONObject(value);
        byte[] iv = Base64.decode(stored.getString("iv"), Base64.NO_WRAP);
        byte[] bytes = Base64.decode(stored.getString("data"), Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        cipher.updateAAD("roblox-mobil-v1".getBytes(StandardCharsets.UTF_8));
        byte[] json = cipher.doFinal(bytes);
        root = new JSONObject(new String(json, StandardCharsets.UTF_8));
        if (!root.has("accounts")) throw new IllegalStateException("Hesap kaydı bulunamadı");
    }

    public void save() throws Exception {
        if (root == null) throw new IllegalStateException("Kasa kilitli");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        cipher.updateAAD("roblox-mobil-v1".getBytes(StandardCharsets.UTF_8));
        byte[] encrypted = cipher.doFinal(root.toString().getBytes(StandardCharsets.UTF_8));
        JSONObject payload = new JSONObject();
        payload.put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
        payload.put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP));
        if (!prefs.edit().putString(DATA, payload.toString()).commit()) {
            throw new IllegalStateException("Kasa kaydedilemedi");
        }
    }

    public String birth() { return root.optString("birth", ""); }
    public String email() { return root.optString("email", ""); }
    public String prefix() { return root.optString("prefix", "Nova"); }

    public void config(String birth, String email, String prefix) throws Exception {
        root.put("birth", birth);
        root.put("email", email);
        root.put("prefix", prefix);
        save();
    }

    public JSONArray accounts() { return root.optJSONArray("accounts"); }

    public Set<String> usedNames() {
        Set<String> names = new HashSet<>();
        JSONArray arr = accounts();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject a = arr.optJSONObject(i);
            if (a != null) names.add(a.optString("username", ""));
        }
        return names;
    }

    public JSONObject addPending(String username, String password, String birth, String email) throws Exception {
        JSONObject r = new JSONObject();
        r.put("id", java.util.UUID.randomUUID().toString());
        r.put("username", username);
        r.put("password", password);
        r.put("birth", birth);
        r.put("email", email);
        r.put("status", "pending");
        r.put("created", System.currentTimeMillis());
        r.put("confirmed", 0L);
        accounts().put(r);
        save();
        return r;
    }

    /** Manually recover an existing account (e.g. from the PC's old TXT export). */
    public void addExisting(String username, String password, String email) throws Exception {
        if (!username.matches("[A-Za-z0-9_]{3,20}") || password.length() < 4)
            throw new IllegalArgumentException("Kullanıcı adı veya şifre geçersiz");
        for (String used : usedNames()) if (used.equalsIgnoreCase(username))
            throw new IllegalArgumentException("Bu kullanıcı adı zaten kasada");
        JSONObject r = new JSONObject();
        r.put("id", java.util.UUID.randomUUID().toString());
        r.put("username", username);
        r.put("password", password);
        r.put("birth", "");
        r.put("email", email);
        r.put("status", "confirmed");
        r.put("created", System.currentTimeMillis());
        r.put("confirmed", System.currentTimeMillis());
        accounts().put(r);
        save();
    }

    /** Import user-provided username:password TXT. Never reads cookies or browser secrets. */
    public int importTxt(String raw) throws Exception {
        String[] lines = raw.split("\\r?\\n");
        if (lines.length > 10000) throw new IllegalArgumentException("Dosyada çok fazla satır var");
        Set<String> seen = new HashSet<>();
        for (String name : usedNames()) seen.add(name.toLowerCase(java.util.Locale.ROOT));
        int imported = 0;
        for (String line : lines) {
            int colon = line.indexOf(':');
            if (colon < 1) continue;
            String username = line.substring(0, colon).trim();
            String password = line.substring(colon+1).trim();
            if (!username.matches("[A-Za-z0-9_]{3,20}") || password.length() < 4 || password.length() > 256) continue;
            if (!seen.add(username.toLowerCase(java.util.Locale.ROOT))) continue;
            JSONObject r = new JSONObject();
            r.put("id", java.util.UUID.randomUUID().toString());
            r.put("username", username);
            r.put("password", password);
            r.put("birth", "");
            r.put("email", "");
            r.put("status", "confirmed");
            r.put("created", System.currentTimeMillis());
            r.put("confirmed", System.currentTimeMillis());
            accounts().put(r);
            imported++;
        }
        if (imported > 0) save();
        return imported;
    }

    public void setConfirmed(String id) throws Exception {
        JSONArray arr = accounts();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r != null && r.optString("id").equals(id)) {
                r.put("status", "confirmed");
                r.put("confirmed", System.currentTimeMillis());
                save();
                return;
            }
        }
        throw new IllegalArgumentException("Kayıt bulunamadı");
    }

    public void delete(String id) throws Exception {
        JSONArray arr = accounts();
        JSONArray kept = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r != null && !r.optString("id").equals(id)) kept.put(r);
        }
        root.put("accounts", kept);
        save();
    }

    public int[] counts() {
        int success = 0, pending = 0;
        JSONArray arr = accounts();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject r = arr.optJSONObject(i);
            if (r == null) continue;
            if ("confirmed".equals(r.optString("status"))) success++;
            else pending++;
        }
        return new int[] {success, pending};
    }

    public String json() { return root.toString(); }

    public int mergeJson(String raw) throws Exception {
        JSONObject incoming = new JSONObject(raw);
        JSONArray arr = incoming.getJSONArray("accounts");
        Set<String> ids = new HashSet<>();
        JSONArray mine = accounts();
        for (int i = 0; i < mine.length(); i++) ids.add(mine.getJSONObject(i).getString("id"));
        int imported = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject a = arr.getJSONObject(i);
            if (!a.has("id") || !a.has("username") || !a.has("password")) continue;
            String id = a.optString("id");
            if (id.isEmpty() || ids.contains(id)) continue;
            JSONObject item = new JSONObject();
            item.put("id", id);
            item.put("username", a.getString("username"));
            item.put("password", a.getString("password"));
            item.put("birth", a.optString("birth", ""));
            item.put("email", a.optString("email", ""));
            item.put("status", "confirmed".equals(a.optString("status")) ? "confirmed" : "pending");
            item.put("created", a.optLong("created", System.currentTimeMillis()));
            item.put("confirmed", a.optLong("confirmed", 0L));
            mine.put(item);
            ids.add(id);
            imported++;
        }
        save();
        return imported;
    }
}
