package com.pixelya.robloxvault;

import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

public final class AccountGenerator {
    private static final SecureRandom RNG = new SecureRandom();
    private static final String LOWER = "abcdefghijkmnopqrstuvwxyz";
    private static final String UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    private static final String DIGIT = "23456789";
    private static final String SYMBOL = "!@#$%*-_";
    private static final String USER_CHARS = LOWER + UPPER + DIGIT;

    private AccountGenerator() { }

    public static String username(String prefix, Set<String> existing) {
        String cleaned = prefix == null ? "Nova" : prefix.replaceAll("[^A-Za-z0-9]", "");
        if (cleaned.isEmpty()) cleaned = "Nova";
        if (cleaned.length() > 9) cleaned = cleaned.substring(0, 9);
        Set<String> normalized = new HashSet<>();
        for (String v : existing) normalized.add(v.toLowerCase(java.util.Locale.ROOT));
        for (int tries = 0; tries < 50; tries++) {
            StringBuilder sb = new StringBuilder(cleaned);
            for (int i = 0; i < 8; i++) sb.append(USER_CHARS.charAt(RNG.nextInt(USER_CHARS.length())));
            String candidate = sb.toString();
            if (!normalized.contains(candidate.toLowerCase(java.util.Locale.ROOT))) return candidate;
        }
        throw new IllegalStateException("Benzersiz kullanıcı adı üretilemedi");
    }

    public static String password() {
        char[] out = new char[22];
        String[] groups = {LOWER, UPPER, DIGIT, SYMBOL};
        for (int i = 0; i < groups.length; i++) {
            String set = groups[i];
            out[i] = set.charAt(RNG.nextInt(set.length()));
        }
        String all = LOWER + UPPER + DIGIT + SYMBOL;
        for (int i = 4; i < out.length; i++) out[i] = all.charAt(RNG.nextInt(all.length()));
        for (int i = out.length - 1; i > 0; i--) {
            int j = RNG.nextInt(i + 1);
            char swap = out[i]; out[i] = out[j]; out[j] = swap;
        }
        return new String(out);
    }
}
