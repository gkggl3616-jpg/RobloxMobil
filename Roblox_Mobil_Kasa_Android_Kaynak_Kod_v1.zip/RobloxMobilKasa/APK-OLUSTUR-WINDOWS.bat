@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Roblox Mobil Kasa - APK Olustur
set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "%ANDROID_HOME%\platforms\android-35\android.jar" (
 echo HATA: Android SDK Platform 35 bulunamadi.
 echo Android Studio kurup SDK Manager icinden Android API 35 yukle.
 pause
 exit /b 1
)
java -version >nul 2>&1
if errorlevel 1 (
 echo HATA: Java 17 gerekli. Android Studio veya JDK 17 kur.
 pause
 exit /b 1
)
if not exist ".tooling\gradle-8.9\bin\gradle.bat" (
 echo Gradle 8.9 indiriliyor (ilk derlemede internet gerekli)...
 if not exist ".tooling" mkdir ".tooling"
 powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '.tooling\gradle-8.9-bin.zip'; Expand-Archive -LiteralPath '.tooling\gradle-8.9-bin.zip' -DestinationPath '.tooling' -Force"
 if not exist ".tooling\gradle-8.9\bin\gradle.bat" (
  echo HATA: Gradle indirme basarisiz. Internetini kontrol et.
  pause
  exit /b 1
 )
)
call ".tooling\gradle-8.9\bin\gradle.bat" --no-daemon assembleDebug
if errorlevel 1 (
 echo APK derlemesi basarisiz oldu. Yukaridaki hata metnini paylasabilirsin.
 pause
 exit /b 1
)
echo.
echo APK HAZIR: %CD%\app\build\outputs\apk\debug\app-debug.apk
explorer "app\build\outputs\apk\debug"
pause
